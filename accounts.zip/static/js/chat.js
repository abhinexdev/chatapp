document.addEventListener('DOMContentLoaded', () => {
  const chatBox = document.getElementById('chatMessages');
  const messageInput = document.getElementById('messageInput');
  const sendBtn = document.getElementById('sendBtn');
  const chatData = document.getElementById('chatData');
  
  const conversationId = chatData ? chatData.dataset.conversationId : null;
  const currentUserId = chatData ? chatData.dataset.currentUserId : null;

  let replyToId = null;
  let chatSocket = null;

  if (conversationId) {
    const protocol = window.location.protocol === 'https:' ? 'wss://' : 'ws://';
    const wsUrl = `${protocol}${window.location.host}/ws/chat/${conversationId}/`;
    chatSocket = new WebSocket(wsUrl);

    chatSocket.onmessage = function (e) {
      const data = JSON.parse(e.data);

      if (data.type === 'chat_message') {
        appendMessage(data);
        scrollToBottom();
      } else if (data.type === 'message_deleted') {
        const bubble = document.getElementById(`message-content-${data.message_id}`);
        if (bubble) bubble.innerHTML = '<i>This message was deleted</i>';
      } else if (data.type === 'message_edited') {
        const bubble = document.getElementById(`message-content-${data.message_id}`);
        if (bubble) {
          bubble.innerText = data.content + ' ';
          const span = document.createElement('span');
          span.className = 'edited-tag';
          span.innerText = '(edited)';
          bubble.appendChild(span);
        }
      } else if (data.type === 'reaction_update') {
        updateReactions(data.message_id, data.reactions);
      }
    };
  }

  function appendMessage(data) {
    const isOwn = data.sender_id == currentUserId;
    const msgDiv = document.createElement('div');
    msgDiv.className = `message ${isOwn ? 'own' : 'other'}`;
    msgDiv.id = `message-${data.message_id}`;
    msgDiv.dataset.id = data.message_id;

    let contentHtml = '';

    if (data.reply_to) {
      contentHtml += `
                <div class="reply-quote" onclick="document.getElementById('message-${data.reply_to.id}').scrollIntoView({behavior: 'smooth'})">
                    <strong>${data.reply_to.sender_username}</strong>
                    <p>${data.reply_to.content}</p>
                </div>
            `;
    }

    contentHtml += `<div class="bubble" id="message-content-${data.message_id}">${data.content}</div>`;

    contentHtml += `
            <div class="reaction-bar">
                ${['👍', '❤️', '😂', '😮', '😢', '🔥'].map(emoji =>
      `<span onclick="reactMessage(${data.message_id}, '${emoji}')">${emoji}</span>`
    ).join('')}
            </div>
            <div class="reactions-summary" id="reactions-${data.message_id}"></div>
        `;

    msgDiv.innerHTML = contentHtml;
    chatBox.appendChild(msgDiv);

    if (isOwn) {
      msgDiv.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        showContextMenu(e.pageX, e.pageY, data.message_id);
      });
    }
  }

  if (sendBtn && chatSocket) {
    sendBtn.addEventListener('click', () => {
      const content = messageInput.value.trim();
      if (content) {
        chatSocket.send(JSON.stringify({
          type: 'chat_message',
          content: content,
          reply_to: replyToId
        }));
        messageInput.value = '';
        if (window.cancelReply) window.cancelReply();
      }
    });

    // Also support Enter to send
    messageInput.addEventListener('keypress', (e) => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendBtn.click();
      }
    });
  }

  window.deleteMessage = async function (id) {
    await fetch(`/api/message/${id}/delete/`, {
      method: 'POST',
      headers: { 'X-CSRFToken': getCookie('csrftoken') }
    });
    hideContextMenu();
  };

  window.initEditMessage = function (id) {
    const bubble = document.getElementById(`message-content-${id}`);
    const currentText = bubble.innerText;
    bubble.innerHTML = `
            <input type="text" id="edit-input-${id}" value="${currentText}" class="edit-input">
            <button onclick="saveEdit(${id})">Save</button>
            <button onclick="cancelEdit(${id}, '${currentText}')">Cancel</button>
        `;
    hideContextMenu();
  };

  window.saveEdit = async function (id) {
    const input = document.getElementById(`edit-input-${id}`);
    await fetch(`/api/message/${id}/edit/`, {
      method: 'POST',
      headers: {
        'X-CSRFToken': getCookie('csrftoken'),
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ content: input.value })
    });
  };

  window.cancelEdit = function (id, original) {
    document.getElementById(`message-content-${id}`).innerText = original;
  };

  window.initReply = function (id, content, username) {
    replyToId = id;
    const preview = document.getElementById('reply-preview');
    if (preview) {
      preview.innerHTML = `Replying to <strong>${username}</strong>: ${content} <span onclick="cancelReply()" style="cursor:pointer;float:right;">✕</span>`;
      preview.style.display = 'block';
    }
    hideContextMenu();
  };

  window.cancelReply = function () {
    replyToId = null;
    const preview = document.getElementById('reply-preview');
    if (preview) {
      preview.style.display = 'none';
      preview.innerHTML = '';
    }
  };

  window.reactMessage = async function (id, emoji) {
    await fetch(`/api/message/${id}/react/`, {
      method: 'POST',
      headers: {
        'X-CSRFToken': getCookie('csrftoken'),
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ emoji })
    });
  };

  window.createGroup = async function () {
    const name = document.getElementById('group-name').value;
    if (!name) return;
    const res = await fetch('/group/create/', {
      method: 'POST',
      headers: {
        'X-CSRFToken': getCookie('csrftoken'),
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ name: name, member_ids: [] })
    });
    if (res.ok) {
      window.location.reload();
    }
  };

  function updateReactions(messageId, reactions) {
    const summaryDiv = document.getElementById(`reactions-${messageId}`);
    if (!summaryDiv) return;
    summaryDiv.innerHTML = reactions.map(r => `${r.emoji} ${r.count}`).join(' ');
  }

  function scrollToBottom() {
    if (chatBox) chatBox.scrollTop = chatBox.scrollHeight;
  }

  function getCookie(name) {
    let cookieValue = null;
    if (document.cookie && document.cookie !== '') {
      const cookies = document.cookie.split(';');
      for (let i = 0; i < cookies.length; i++) {
        const cookie = cookies[i].trim();
        if (cookie.substring(0, name.length + 1) === (name + '=')) {
          cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
          break;
        }
      }
    }
    return cookieValue;
  }

  const contextMenu = document.createElement('div');
  contextMenu.id = 'context-menu';
  contextMenu.className = 'context-menu';
  document.body.appendChild(contextMenu);

  function showContextMenu(x, y, messageId) {
    const bubble = document.getElementById(`message-content-${messageId}`);
    const content = bubble ? bubble.innerText.replace('(edited)', '').trim() : '...';
    contextMenu.innerHTML = `
            <div onclick="initEditMessage(${messageId})">Edit</div>
            <div onclick="deleteMessage(${messageId})">Delete</div>
            <div onclick="initReply(${messageId}, '${content.replace(/'/g, "\\'")}', 'User')">Reply</div>
        `;
    contextMenu.style.left = `${x}px`;
    contextMenu.style.top = `${y}px`;
    contextMenu.style.display = 'block';
  }

  function hideContextMenu() {
    contextMenu.style.display = 'none';
  }

  document.addEventListener('click', hideContextMenu);

  // Extracted Inline JavaScript
  const btnNewGroup = document.getElementById('btnNewGroup');
  const groupModal = document.getElementById('group-modal');
  const btnCreateGroupSubmit = document.getElementById('btnCreateGroupSubmit');
  const btnCancelGroup = document.getElementById('btnCancelGroup');
  const lightbox = document.getElementById('lightbox');

  if (btnNewGroup) {
    btnNewGroup.addEventListener('click', () => {
      if (groupModal) groupModal.classList.remove('hidden');
    });
  }

  if (btnCreateGroupSubmit) {
    btnCreateGroupSubmit.addEventListener('click', () => {
      if (typeof window.createGroup === 'function') window.createGroup();
    });
  }

  if (btnCancelGroup) {
    btnCancelGroup.addEventListener('click', () => {
      if (groupModal) groupModal.classList.add('hidden');
    });
  }

  if (lightbox) {
    lightbox.addEventListener('click', () => {
      lightbox.classList.add('hidden');
    });
  }

  document.addEventListener('click', (e) => {
    if (e.target.classList.contains('js-lightbox-trigger')) {
      const lightboxImg = document.getElementById('lightboxImg');
      if (lightboxImg && lightbox) {
        lightboxImg.src = e.target.src;
        lightbox.classList.remove('hidden');
      }
    }
  });

  // Global context menu for own messages
  document.addEventListener('contextmenu', (e) => {
    const msgDiv = e.target.closest('.message.message--out');
    if (msgDiv && msgDiv.dataset.messageId) {
      e.preventDefault();
      showContextMenu(e.pageX, e.pageY, msgDiv.dataset.messageId);
    }
  });

  // Emoji Picker Logic
  const emojiBtn = document.getElementById('emojiBtn');
  const emojiPicker = document.getElementById('emojiPicker');
  const emojiGrid = document.getElementById('emojiGrid');
  
  if (emojiBtn && emojiPicker && emojiGrid) {
    const emojis = ['😀', '😂', '🥰', '😎', '😭', '😡', '👍', '🙏', '🔥', '🎉', '💔', '💯'];
    emojiGrid.innerHTML = emojis.map(e => `<button type="button" class="emoji-btn-item">${e}</button>`).join('');
    
    emojiBtn.addEventListener('click', (e) => {
      e.preventDefault();
      emojiPicker.classList.toggle('open');
    });
    
    emojiGrid.addEventListener('click', (e) => {
      if (e.target.classList.contains('emoji-btn-item')) {
        const messageInput = document.getElementById('messageInput');
        if (messageInput) messageInput.value += e.target.innerText;
        emojiPicker.classList.remove('open');
      }
    });

    // Close emoji picker when clicking outside
    document.addEventListener('click', (e) => {
      if (!emojiBtn.contains(e.target) && !emojiPicker.contains(e.target)) {
        emojiPicker.classList.remove('open');
      }
    });
  }
});
