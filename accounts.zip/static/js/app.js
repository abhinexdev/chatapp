// static/js/app.js
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/static/js/sw.js')
            .then(registration => {
                console.log('ServiceWorker registration successful with scope: ', registration.scope);
            })
            .catch(error => {
                console.log('ServiceWorker registration failed: ', error);
            });
    });
}

let deferredPrompt;
window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    
    if (!localStorage.getItem('pwaPromptDismissed')) {
        const installBtn = document.createElement('button');
        installBtn.id = 'pwa-install-btn';
        installBtn.innerText = 'Install Pulse Chat App';
        installBtn.className = 'install-prompt-btn';
        document.body.appendChild(installBtn);
        
        installBtn.addEventListener('click', () => {
            deferredPrompt.prompt();
            deferredPrompt.userChoice.then((choiceResult) => {
                if (choiceResult.outcome === 'accepted') {
                    console.log('User accepted the A2HS prompt');
                }
                deferredPrompt = null;
                installBtn.remove();
                closeBtn.remove();
            });
        });

        const closeBtn = document.createElement('span');
        closeBtn.innerText = '✕';
        closeBtn.className = 'install-prompt-close';
        closeBtn.onclick = () => {
            localStorage.setItem('pwaPromptDismissed', 'true');
            installBtn.remove();
            closeBtn.remove();
        };
        document.body.appendChild(closeBtn);
    }
});

// Offline Retry Logic
document.addEventListener('DOMContentLoaded', () => {
    const btnRetryOffline = document.getElementById('btnRetryOffline');
    if (btnRetryOffline) {
        btnRetryOffline.addEventListener('click', () => {
            window.location.reload();
        });
    }
});
