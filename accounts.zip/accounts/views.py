"""
accounts/views.py
"""
from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.views.decorators.http import require_GET

from .forms import RegisterForm, LoginForm, ProfileUpdateForm
from .models import User


def register_view(request):
    if request.user.is_authenticated:
        return redirect('chat:index')

    form = RegisterForm(request.POST or None, request.FILES or None)
    if request.method == 'POST' and form.is_valid():
        user = form.save()
        login(request, user)
        messages.success(request, f'Welcome, {user.username}!')
        return redirect('chat:index')

    return render(request, 'register.html', {'form': form})


def login_view(request):
    if request.user.is_authenticated:
        return redirect('chat:index')

    form = LoginForm(request, data=request.POST or None)
    if request.method == 'POST' and form.is_valid():
        user = form.get_user()
        login(request, user)
        return redirect(request.GET.get('next', 'chat:index'))

    return render(request, 'login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('accounts:login')


@login_required
def profile_view(request):
    form = ProfileUpdateForm(request.POST or None, request.FILES or None, instance=request.user)
    if request.method == 'POST' and form.is_valid():
        form.save()
        messages.success(request, 'Profile updated successfully.')
        return redirect('accounts:profile')

    return render(request, 'profile.html', {'form': form})


@require_GET
def search_users(request):
    query = request.GET.get('q', '').strip()

    # Return empty list for blank query
    if not query:
        return JsonResponse({'users': []})

    users = User.objects.filter(
        username__icontains=query
    ).exclude(id=request.user.id).values(
        'id', 'username', 'is_online', 'last_seen', 'avatar'
    )[:10]

    results = []
    for u in users:
        if u['avatar']:
            avatar_url = '/media/' + u['avatar']
        else:
            avatar_url = '/static/images/default_avatar.png'

        results.append({
            'id': u['id'],
            'username': u['username'],
            'is_online': u['is_online'],
            'avatar': avatar_url,
        })

    return JsonResponse({'users': results})
